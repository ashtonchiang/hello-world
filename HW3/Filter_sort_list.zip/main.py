#Ashton Chiang
#1869119
#CIS 2348
#Professor Ratner

integers = input().split()
non_neg_int=[]

for num in integers:
    num = int(num)
    if num >= 0:
        non_neg_int.append(num)

non_neg_int.sort()

for i in non_neg_int:
    print(i,end=' ')







