#Ashton Chiang
#1869119
#CIS 2348
#Professor Ratner

words = input().split()
for word in words:
    count = 0
    for w in words:
        if w == word:
            count += 1
    print(word, count)







